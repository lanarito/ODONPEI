// ========== TURNERO DIGITAL ==========

const TURNOS_KEY = 'ODONPEI_TURNOS';
let semanaOffset = 0;
let turnosListenerActivo = false;
let turnosCelularesUnificados = false;
let turnosYaDeduplicados = false;

function obtenerTurnos() {
    return JSON.parse(localStorage.getItem(TURNOS_KEY) || '[]');
}

function guardarTurnosStorage(turnos) {
    localStorage.setItem(TURNOS_KEY, JSON.stringify(turnos));
}

async function sincronizarTurnosDesdeFirebase() {
    if (typeof obtenerTurnosDesdeFirestore !== 'function') return;
    try {
        const remotos = await obtenerTurnosDesdeFirestore();
        if (remotos.length > 0) {
            localStorage.setItem(TURNOS_KEY, JSON.stringify(remotos));
            renderizarSemana();
        } else {
            const locales = obtenerTurnos();
            for (const t of locales) {
                if (!t.firebaseId) await guardarTurnoEnFirestore(t);
            }
        }
    } catch (e) { console.warn('Sync turnos:', e); }
}

function getLunesDeSemana(offset) {
    const hoy = new Date();
    const dia = hoy.getDay();
    const diffLunes = dia === 0 ? -6 : 1 - dia;
    const lunes = new Date(hoy);
    lunes.setDate(hoy.getDate() + diffLunes + offset * 7);
    lunes.setHours(0, 0, 0, 0);
    return lunes;
}

function fechaStr(date) {
    return date.toISOString().split('T')[0];
}

function cargarTurnos() {
    semanaOffset = 0;
    renderizarTurnosHoy();
    renderizarSemana();
    setTimeout(async () => {
        // Firebase es la FUENTE DE VERDAD.
        // OJO: antes se re-subían TODOS los turnos locales al abrir la página, y eso
        // "resucitaba" turnos borrados en otro dispositivo (la copia vieja los volvía
        // a subir). Ahora NO hacemos eso: solo subimos los turnos realmente nuevos
        // (creados acá y que nunca llegaron a la nube) y después pisamos lo local con
        // lo que hay en la nube.
        if (typeof obtenerTurnosDesdeFirestore === 'function') {
            try {
                const remotos = await obtenerTurnosDesdeFirestore();
                const idsRemotos = new Set(remotos.map(t => t.id));
                const locales = obtenerTurnos();
                // "Nuevos de verdad": sin firebaseId (nunca subidos) y que no existan ya en la nube
                const nuevos = locales.filter(t => !t.firebaseId && !idsRemotos.has(t.id));
                if (nuevos.length && typeof guardarTurnoEnFirestore === 'function') {
                    for (const t of nuevos) await guardarTurnoEnFirestore(t);
                }
                // La verdad final = lo que hay en la nube (ya con los nuevos incluidos)
                const finales = nuevos.length ? await obtenerTurnosDesdeFirestore() : remotos;
                guardarTurnosStorage(finales);
                renderizarTurnosHoy();
                renderizarSemana();
            } catch (e) { console.warn('Carga turnos:', e); }
        }

        // Mantenimiento automático: si el mismo turno quedó guardado dos veces, se
        // junta en uno solo. Es idempotente: si no hay nada repetido, no hace nada.
        if (!turnosYaDeduplicados) {
            turnosYaDeduplicados = true;
            try { await deduplicarTurnosAuto(); } catch (e) { console.warn('Deduplicando turnos:', e); }
        }

        // Un ÚNICO listener en tiempo real (antes se apilaba uno nuevo por cada visita
        // a la página de Turnos). Borrar/modificar en cualquier estación se refleja acá.
        if (!turnosListenerActivo && typeof sincronizarTurnosEnTiempoReal === 'function') {
            turnosListenerActivo = true;
            sincronizarTurnosEnTiempoReal((turnosRemotos) => {
                guardarTurnosStorage(turnosRemotos);
                renderizarTurnosHoy();
                renderizarSemana();
                // Si el panel de recordatorios está abierto, que se actualice solo
                if (typeof renderPanelRecordatorios === 'function') renderPanelRecordatorios();

                // Con los turnos ya frescos de la nube, dejar los teléfonos en formato único
                if (!turnosCelularesUnificados && typeof unificarCelularesAuto === 'function') {
                    turnosCelularesUnificados = true;
                    unificarCelularesAuto().catch(e => console.warn('Unificando teléfonos:', e));
                }
            });
        }
    }, 800);
}

function renderizarTurnosHoy() {
    // El aviso de recordatorios se refresca junto con los turnos de hoy
    if (typeof renderizarAvisoRecordatorios === 'function') renderizarAvisoRecordatorios();

    const section = document.getElementById('turnos-hoy-section');
    if (!section) return;
    const hoy = fechaStr(new Date());
    const turnos = obtenerTurnos().filter(t => t.fecha === hoy)
        .sort((a, b) => a.hora.localeCompare(b.hora));

    if (turnos.length === 0) {
        section.innerHTML = `<div class="hoy-vacio">Sin turnos para hoy</div>`;
        return;
    }

    const ESTADO_LETRA = { pendiente:'P', confirmado:'C', cancelado:'X', reprogramado:'R', asistio:'A', noasistio:'NA' };
    section.innerHTML = `
        <div class="hoy-header">Hoy — ${new Date().toLocaleDateString('es-AR', { weekday:'long', day:'numeric', month:'long' })}</div>
        <div class="hoy-lista">
            ${turnos.map(t => `
                <div class="hoy-turno estado-${t.estado}" onclick="verTurno('${t.id}')">
                    <span class="hoy-hora">${t.hora} a ${horaFinTurno(t)}</span>
                    <span class="hoy-nombre">${t.pacienteNombre}</span>
                    ${t.celular ? `<span class="hoy-cel">📱 ${t.celular}</span>` : ''}
                    <span class="cal-turno-badge">${ESTADO_LETRA[t.estado] || 'P'}</span>
                </div>
            `).join('')}
        </div>`;
}

function buscarTurnos(query) {
    const res = document.getElementById('resultados-busqueda-turnos');
    if (!res) return;
    if (!query.trim()) { res.innerHTML = ''; return; }

    const q = query.toLowerCase();
    const turnos = obtenerTurnos()
        .filter(t => t.pacienteNombre.toLowerCase().includes(q))
        .sort((a, b) => a.fecha.localeCompare(b.fecha) || a.hora.localeCompare(b.hora));

    if (turnos.length === 0) {
        res.innerHTML = `<div class="busqueda-vacia">No se encontraron turnos para "${query}"</div>`;
        return;
    }

    const ESTADO_LETRA = { pendiente:'P', confirmado:'C', cancelado:'X', reprogramado:'R', asistio:'A', noasistio:'NA' };
    res.innerHTML = `
        <div class="busqueda-lista">
            <div class="busqueda-titulo">${turnos.length} turno(s) encontrado(s)</div>
            ${turnos.map(t => {
                const fecha = new Date(t.fecha + 'T12:00:00').toLocaleDateString('es-AR', { weekday:'short', day:'numeric', month:'short', year:'numeric' });
                return `<div class="hoy-turno estado-${t.estado}" onclick="verTurno('${t.id}')">
                    <span class="hoy-hora">${fecha} ${t.hora}</span>
                    <span class="hoy-nombre">${t.pacienteNombre}</span>
                    <span class="cal-turno-badge">${ESTADO_LETRA[t.estado] || 'P'}</span>
                </div>`;
            }).join('')}
        </div>`;
}

function navegarSemana(dir) {
    semanaOffset = dir === 0 ? 0 : semanaOffset + dir;
    renderizarSemana();
}

// ---------- Duración: un turno ocupa varias franjas de media hora ----------
// Un turno de 1 hora a las 16:00 ocupa la casilla de las 16:00 Y la de las 16:30.
// Si solo se pinta la primera, la de las 16:30 se ve libre y confunde.

function franjasQueOcupa(turno) {
    return Math.max(1, Math.ceil((parseInt(turno.duracion) || 30) / 30));
}

function horaFinTurno(turno) {
    const [h, m] = String(turno.hora || '00:00').split(':').map(Number);
    const total = h * 60 + m + (parseInt(turno.duracion) || 30);
    return String(Math.floor(total / 60) % 24).padStart(2, '0') + ':' +
           String(total % 60).padStart(2, '0');
}

// Devuelve { 'fecha|hora': [{ turno, inicio }] } con TODAS las franjas ocupadas
function mapearOcupacion(turnos, horas) {
    const ocupacion = {};
    turnos.forEach(t => {
        const desde = horas.indexOf(t.hora);
        if (desde === -1) return;                      // horario fuera de la grilla
        const franjas = franjasQueOcupa(t);
        for (let k = 0; k < franjas && desde + k < horas.length; k++) {
            const clave = t.fecha + '|' + horas[desde + k];
            (ocupacion[clave] = ocupacion[clave] || []).push({ turno: t, inicio: k === 0 });
        }
    });
    return ocupacion;
}

function renderizarSemana() {
    const lunes = getLunesDeSemana(semanaOffset);
    const dias = Array.from({ length: 6 }, (_, i) => {
        const d = new Date(lunes);
        d.setDate(lunes.getDate() + i);
        return d;
    });

    const titulo = document.getElementById('semana-titulo');
    if (titulo) {
        const ini = dias[0].toLocaleDateString('es-AR', { day: 'numeric', month: 'long' });
        const fin = dias[5].toLocaleDateString('es-AR', { day: 'numeric', month: 'long', year: 'numeric' });
        titulo.textContent = `${ini} — ${fin}`;
    }

    const turnos = obtenerTurnos();
    const horas = [];
    for (let h = 15; h <= 19; h++) {
        horas.push(`${String(h).padStart(2, '0')}:00`);
        horas.push(`${String(h).padStart(2, '0')}:30`);
    }
    horas.push('20:00');

    const DIAS_CORTOS = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
    const hoyStr = fechaStr(new Date());

    let html = '<div class="cal-grid">';

    // Encabezado
    html += '<div class="cal-corner"></div>';
    dias.forEach((d, i) => {
        const esHoy = fechaStr(d) === hoyStr;
        html += `<div class="cal-header-dia${esHoy ? ' cal-hoy' : ''}">
            <span class="cal-dia-nombre">${DIAS_CORTOS[i]}</span>
            <span class="cal-dia-num">${d.getDate()}</span>
        </div>`;
    });

    // Todas las franjas que ocupa cada turno según su duración
    const ocupacion = mapearOcupacion(turnos, horas);
    const ESTADO_LETRA = { pendiente:'P', confirmado:'C', cancelado:'X', reprogramado:'R', asistio:'A', noasistio:'NA' };

    // Filas horarias
    horas.forEach(hora => {
        const esMediaHora = hora.endsWith(':30');
        html += `<div class="cal-hora-label${esMediaHora ? ' cal-media-hora' : ''}">${hora}</div>`;
        dias.forEach(d => {
            const fStr = fechaStr(d);
            const slot = ocupacion[fStr + '|' + hora] || [];
            html += `<div class="cal-celda${esMediaHora ? ' cal-celda-media' : ''}" onclick="mostrarFormTurno('${fStr}','${hora}')">`;
            slot.forEach(({ turno: t, inicio }) => {
                const letra = ESTADO_LETRA[t.estado] || 'P';
                // La franja donde empieza lleva la letra del estado; las que siguen
                // llevan una flecha, para ver de un vistazo dónde arranca el turno
                html += `<div class="cal-turno estado-${t.estado}${inicio ? '' : ' cal-turno-sigue'}" onclick="event.stopPropagation();verTurno('${t.id}')" title="${t.pacienteNombre} · ${t.hora} a ${horaFinTurno(t)}">
                    <span class="cal-turno-badge">${inicio ? letra : '↓'}</span> ${t.pacienteNombre}
                </div>`;
            });
            html += '</div>';
        });
    });

    html += '</div>';
    document.getElementById('calendario-semana').innerHTML = html;
}

function mostrarFormTurno(fecha = '', hora = '') {
    const horas = [];
    for (let h = 15; h <= 19; h++) {
        horas.push(`${String(h).padStart(2, '0')}:00`);
        horas.push(`${String(h).padStart(2, '0')}:30`);
    }
    horas.push('20:00');

    const horaOpts = horas.map(h =>
        `<option value="${h}"${h === hora ? ' selected' : ''}>${h}</option>`
    ).join('');

    document.getElementById('form-turno-container').innerHTML = `
        <div class="modal-overlay" onclick="cerrarFormTurno()">
            <div class="modal-content" onclick="event.stopPropagation()">
                <h3 style="margin-bottom:20px; color:#333;">Nuevo Turno</h3>
                <form onsubmit="guardarTurno(event)">
                    <div class="form-group">
                        <label>Nombre *</label>
                        <input type="text" id="turno-nombre" placeholder="Ej: Pepe Robledo" required autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Celular</label>
                        <input type="tel" id="turno-celular" value="${PREFIJO_LOCAL}" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Otro celular (opcional)</label>
                        <input type="tel" id="turno-celular2" placeholder="${PREFIJO_LOCAL}" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Fecha *</label>
                        <input type="date" id="turno-fecha" value="${fecha}" required>
                    </div>
                    <div class="form-group">
                        <label>Hora *</label>
                        <select id="turno-hora" required>${horaOpts}</select>
                    </div>
                    <div class="form-group">
                        <label>Duración</label>
                        <select id="turno-duracion">
                            <option value="30">30 minutos</option>
                            <option value="60" selected>1 hora</option>
                            <option value="90">1 hora 30 min</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Notas</label>
                        <textarea id="turno-notas" rows="2" placeholder="Tratamiento, observaciones..."></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="button" onclick="cerrarFormTurno()" class="btn btn-outline">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Guardar Turno</button>
                    </div>
                </form>
            </div>
        </div>`;

    setTimeout(() => document.getElementById('turno-nombre')?.focus(), 100);
}

function cerrarFormTurno() {
    document.getElementById('form-turno-container').innerHTML = '';
}

function guardarTurno(event) {
    event.preventDefault();
    const idEdicion = document.getElementById('turno-id-edicion')?.value || '';

    if (idEdicion) {
        // Modo edición — actualizar existente
        const turnos = obtenerTurnos();
        const t = turnos.find(t => t.id === idEdicion);
        if (t) {
            const nuevaFecha = document.getElementById('turno-fecha').value;
            const nuevaHora  = document.getElementById('turno-hora').value;
            // Si se movió el turno, el recordatorio que se mandó ya no sirve:
            // hay que volver a avisarle al paciente el día/hora nuevo.
            if (t.recordadoEn && (nuevaFecha !== t.fecha || nuevaHora !== t.hora)) t.recordadoEn = '';

            t.pacienteNombre = aMayusculas(document.getElementById('turno-nombre').value.trim());
            const nums       = repartirNumeros(document.getElementById('turno-celular').value,
                                               document.getElementById('turno-celular2')?.value || '');
            t.celular        = nums.uno;
            t.celular2       = nums.dos;
            t.fecha          = nuevaFecha;
            t.hora           = nuevaHora;
            t.duracion       = parseInt(document.getElementById('turno-duracion').value);
            t.notas          = document.getElementById('turno-notas').value.trim();
            guardarTurnosStorage(turnos);
            if (typeof actualizarTurnoEnFirestore === 'function') actualizarTurnoEnFirestore(t).catch(() => {
                // Si no existe en Firebase (no tiene firebaseId), lo crea
                if (!t.firebaseId && typeof guardarTurnoEnFirestore === 'function') {
                    guardarTurnoEnFirestore(t).then(() => {
                        const todos = obtenerTurnos();
                        const idx = todos.findIndex(x => x.id === t.id);
                        if (idx !== -1) { todos[idx].firebaseId = t.firebaseId; guardarTurnosStorage(todos); }
                    });
                }
            });
        }
    } else {
        // Modo nuevo
        const numsTurno = repartirNumeros(document.getElementById('turno-celular').value,
                                          document.getElementById('turno-celular2')?.value || '');
        const turno = {
            id: Date.now().toString(),
            pacienteNombre: aMayusculas(document.getElementById('turno-nombre').value.trim()),
            celular: numsTurno.uno,
            celular2: numsTurno.dos,
            fecha: document.getElementById('turno-fecha').value,
            hora: document.getElementById('turno-hora').value,
            duracion: parseInt(document.getElementById('turno-duracion').value),
            notas: document.getElementById('turno-notas').value.trim(),
            estado: 'pendiente',
            fechaCreacion: new Date().toISOString()
        };
        const turnos = obtenerTurnos();
        turnos.push(turno);
        guardarTurnosStorage(turnos);
        if (typeof guardarTurnoEnFirestore === 'function') {
            guardarTurnoEnFirestore(turno).then(() => {
                // Guardar el firebaseId de vuelta en localStorage para que el sistema sepa que ya está en la nube
                const todos = obtenerTurnos();
                const idx = todos.findIndex(t => t.id === turno.id);
                if (idx !== -1) { todos[idx].firebaseId = turno.firebaseId; guardarTurnosStorage(todos); }
            });
        }
    }

    cerrarFormTurno();
    renderizarTurnosHoy();
    renderizarSemana();
}

function editarTurno(id) {
    const turno = obtenerTurnos().find(t => t.id === id);
    if (!turno) return;

    const horas = [];
    for (let h = 15; h <= 19; h++) {
        horas.push(`${String(h).padStart(2, '0')}:00`);
        horas.push(`${String(h).padStart(2, '0')}:30`);
    }
    horas.push('20:00');

    const horaOpts = horas.map(h =>
        `<option value="${h}"${h === turno.hora ? ' selected' : ''}>${h}</option>`
    ).join('');

    document.getElementById('form-turno-container').innerHTML = `
        <div class="modal-overlay" onclick="cerrarFormTurno()">
            <div class="modal-content" onclick="event.stopPropagation()">
                <h3 style="margin-bottom:16px; color:#333;">✏️ Modificar Turno</h3>
                <form onsubmit="guardarTurno(event)">
                    <input type="hidden" id="turno-id-edicion" value="${turno.id}">
                    <div class="form-group">
                        <label>Nombre *</label>
                        <input type="text" id="turno-nombre" value="${turno.pacienteNombre}" required autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Celular</label>
                        <input type="tel" id="turno-celular" value="${turno.celular || PREFIJO_LOCAL}" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Otro celular (opcional)</label>
                        <input type="tel" id="turno-celular2" value="${turno.celular2 || ''}" placeholder="${PREFIJO_LOCAL}" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Fecha *</label>
                        <input type="date" id="turno-fecha" value="${turno.fecha}" required>
                    </div>
                    <div class="form-group">
                        <label>Hora *</label>
                        <select id="turno-hora" required>${horaOpts}</select>
                    </div>
                    <div class="form-group">
                        <label>Duración</label>
                        <select id="turno-duracion">
                            <option value="30"${turno.duracion===30?' selected':''}>30 minutos</option>
                            <option value="60"${turno.duracion===60?' selected':''}>1 hora</option>
                            <option value="90"${turno.duracion===90?' selected':''}>1 hora 30 min</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Notas</label>
                        <textarea id="turno-notas" rows="2">${turno.notas || ''}</textarea>
                    </div>
                    <div class="form-actions">
                        <button type="button" onclick="cerrarFormTurno()" class="btn btn-outline">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>`;
    setTimeout(() => document.getElementById('turno-nombre')?.focus(), 100);
}

function verTurno(id) {
    const turno = obtenerTurnos().find(t => t.id === id);
    if (!turno) return;
    const fechaLegible = new Date(turno.fecha + 'T12:00:00').toLocaleDateString('es-AR', {
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
    document.getElementById('form-turno-container').innerHTML = `
        <div class="modal-overlay" onclick="cerrarFormTurno()">
            <div class="modal-content" onclick="event.stopPropagation()">
                <h3 style="margin-bottom:16px; color:#333;">${turno.pacienteNombre}</h3>
                <p style="margin-bottom:8px;">📅 <strong>${fechaLegible}</strong></p>
                <p style="margin-bottom:8px;">🕐 ${turno.hora} a ${horaFinTurno(turno)} · ${turno.duracion} min</p>
                ${turno.celular ? `<p style="margin-bottom:8px;">📱 ${turno.celular}</p>` : ''}
                ${turno.celular2 ? `<p style="margin-bottom:8px;">📱 ${turno.celular2} <span style="color:#999; font-size:12px;">(2º)</span></p>` : ''}
                ${turno.notas ? `<p style="margin-bottom:12px;">📝 ${turno.notas}</p>` : ''}
                <div class="form-group" style="margin-top:16px;">
                    <label>Estado</label>
                    <select id="turno-estado-select" style="padding:8px; border-radius:6px; border:1px solid #ddd; font-size:14px; width:100%;">
                        <option value="pendiente"${turno.estado==='pendiente'?' selected':''}>🟡 P — Pendiente</option>
                        <option value="confirmado"${turno.estado==='confirmado'?' selected':''}>🔵 C — Confirmado</option>
                        <option value="cancelado"${turno.estado==='cancelado'?' selected':''}>🔴 X — Cancelado</option>
                        <option value="reprogramado"${turno.estado==='reprogramado'?' selected':''}>🟠 R — Reprogramado</option>
                        <option value="asistio"${turno.estado==='asistio'?' selected':''}>🟢 A — Asistió</option>
                        <option value="noasistio"${turno.estado==='noasistio'?' selected':''}>⚫ NA — No Asistió</option>
                    </select>
                </div>
                <div style="margin-top:20px; display:flex; flex-direction:column; gap:8px;">
                    ${turno.celular || turno.celular2 ? `
                    <div style="display:flex; gap:8px;">
                        ${turno.celular ? `
                        <button onclick="recordarTurno('${turno.id}', 1); verTurno('${turno.id}')" class="btn" style="background:#25D366; color:white; flex:1;">
                            📲 ${turno.recordadoEn ? 'Volver a recordar' : 'Recordar por WhatsApp'}
                        </button>` : ''}
                        ${turno.celular2 ? `
                        <button onclick="recordarTurno('${turno.id}', 2); verTurno('${turno.id}')" class="btn" style="background:#25D366; color:white; flex:${turno.celular ? '0 0 auto' : '1'};">
                            📲 ${turno.celular ? '2º' : 'Recordar por WhatsApp'}
                        </button>` : ''}
                    </div>
                    ${turno.recordadoEn ? `<div style="font-size:12px; color:#4CAF50; text-align:center; margin-top:-2px;">✅ Recordado el ${new Date(turno.recordadoEn).toLocaleString('es-AR', { day:'numeric', month:'short', hour:'2-digit', minute:'2-digit' })}</div>` : ''}
                    ` : ''}
                    <div style="display:flex; gap:8px;">
                        <button onclick="editarTurno('${turno.id}')" class="btn btn-secondary" style="flex:1;">✏️ Modificar</button>
                        <button onclick="guardarEstadoTurno('${turno.id}')" class="btn btn-primary" style="flex:1;">Guardar</button>
                    </div>
                    <div style="display:flex; gap:8px;">
                        <button onclick="eliminarTurno('${turno.id}')" class="btn btn-danger" style="flex:1;">Eliminar</button>
                        <button onclick="cerrarFormTurno()" class="btn btn-outline" style="flex:1;">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>`;
}

function guardarEstadoTurno(id) {
    const estado = document.getElementById('turno-estado-select')?.value;
    if (!estado) return;
    const turnos = obtenerTurnos();
    const t = turnos.find(t => t.id === id);
    if (t) {
        t.estado = estado;
        guardarTurnosStorage(turnos);
        if (typeof actualizarTurnoEnFirestore === 'function') actualizarTurnoEnFirestore(t);
        cerrarFormTurno();
        renderizarTurnosHoy();
        renderizarSemana();
    }
}

// Corre sola al abrir Turnos, sin botón y sin preguntar nada.
// OJO: acá "duplicado" es el MISMO turno guardado dos veces (mismo id).
// Que un paciente tenga 5 turnos NO es un duplicado: por eso se agrupa por id
// de turno y nunca por nombre.
async function deduplicarTurnosAuto() {
    if (typeof obtenerTurnosDesdeFirestore !== 'function') return;

    let todos;
    try {
        todos = await obtenerTurnosDesdeFirestore();   // cada uno: .firebaseId (doc) + .id (dato)
    } catch (e) {
        console.warn('No se pudieron leer los turnos para deduplicar:', e);
        return;
    }

    const grupos = {};
    todos.forEach(t => { if (t.id) (grupos[t.id] = grupos[t.id] || []).push(t); });

    const ids = Object.keys(grupos);
    if (todos.length === ids.length) return;   // no hay nada repetido

    console.log(`🧹 ${todos.length} documentos para ${ids.length} turnos. Limpiando duplicados...`);

    let eliminados = 0, errores = 0;
    for (const id of ids) {
        const docs = grupos[id];
        if (docs.length === 1) continue;

        // El documento bueno es el que tiene el id del turno como id de documento
        if (!docs.some(d => d.firebaseId === id)) {
            const base = { ...docs[0] };
            delete base.firebaseId;
            const ok = await guardarTurnoEnFirestore(base);
            if (!ok) { errores++; continue; }
        }

        // Antes de borrar, confirmar que el bueno quedó en la nube
        if (typeof existeTurnoEnFirestore === 'function') {
            const existe = await existeTurnoEnFirestore(id);
            if (!existe) { errores++; continue; }
        }

        for (const d of docs) {
            if (d.firebaseId && d.firebaseId !== id) {
                const ok = await eliminarTurnoDeFirestore(d.firebaseId);
                if (ok) eliminados++; else errores++;
            }
        }
    }

    console.log(`✅ Turnos duplicados limpiados: ${eliminados}` + (errores ? `, ${errores} error(es)` : ''));
}

function recuperarTurnosEnFirebase() {
    const turnos = obtenerTurnos();
    if (turnos.length === 0) {
        alert('No hay turnos en este dispositivo.');
        return;
    }
    if (!confirm(`Se van a subir ${turnos.length} turno(s) a Firebase. ¿Continuar?`)) return;

    let count = 0;
    const promises = turnos.map(t => {
        if (typeof guardarTurnoEnFirestore === 'function') {
            return guardarTurnoEnFirestore(t).then(() => { count++; }).catch(() => {});
        }
        return Promise.resolve();
    });

    Promise.all(promises).then(() => {
        guardarTurnosStorage(turnos);
        alert(`✅ ${count} turno(s) subidos a Firebase.\n\nAhora recargá la página en los otros dispositivos y van a aparecer todos.`);
    });
}

function eliminarTurno(id) {
    if (!confirm('¿Eliminar este turno?')) return;
    const turnos = obtenerTurnos();
    const t = turnos.find(t => t.id === id);
    guardarTurnosStorage(turnos.filter(t => t.id !== id));
    // El documento en Firebase usa el id del turno como id (setDoc por id).
    // Borramos por ese id SIEMPRE (tenga o no firebaseId guardado localmente),
    // así el borrado se propaga a todos los dispositivos y no reaparece.
    const docId = t?.firebaseId || t?.id || id;
    if (docId && typeof eliminarTurnoDeFirestore === 'function') eliminarTurnoDeFirestore(docId);
    cerrarFormTurno();
    renderizarTurnosHoy();
    renderizarSemana();
}
