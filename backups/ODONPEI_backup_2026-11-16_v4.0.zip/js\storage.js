// ========== GESTIÓN DE STORAGE (localStorage + Firebase) ==========

const STORAGE_KEY = 'ODONPEI_PACIENTES';

// Para que el mantenimiento automático corra una sola vez por sesión
let celularesYaUnificados = false;

// Guardar nuevo paciente
function guardar(paciente) {
    paciente.id = Date.now().toString();
    paciente.fechaCreacion = new Date().toISOString();

    // Inicializar campos si no existen
    if (!paciente.odontograma) paciente.odontograma = {};
    if (!paciente.fotos) paciente.fotos = [];
    if (!paciente.archivos) paciente.archivos = [];

    const pacientes = obtenerTodos();
    pacientes.push(paciente);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(pacientes));

    // Guardar en Firebase si está disponible
    if (typeof guardarEnFirestore === 'function') {
        guardarEnFirestore(paciente).then(() => {
            // Actualizar localStorage con el firebaseId que retornó Firestore
            const todos = obtenerTodos();
            const idx = todos.findIndex(p => p.id === paciente.id);
            if (idx !== -1) {
                todos[idx].firebaseId = paciente.firebaseId;
                localStorage.setItem(STORAGE_KEY, JSON.stringify(todos));
            }
            console.log('✅ Paciente guardado en Firebase');
        }).catch(error => {
            console.warn('Guardado en localStorage, Firebase error:', error);
        });
    }

    return paciente;
}

// Obtener todos los pacientes
function obtenerTodos() {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
}

// Obtener paciente por ID
function obtenerPorId(id) {
    const pacientes = obtenerTodos();
    return pacientes.find(p => p.id === id);
}

// Actualizar paciente
function actualizar(paciente) {
    const pacientes = obtenerTodos();
    const index = pacientes.findIndex(p => p.id === paciente.id);

    if (index !== -1) {
        pacientes[index] = paciente;
        localStorage.setItem(STORAGE_KEY, JSON.stringify(pacientes));

        // Actualizar en Firebase
        if (typeof actualizarEnFirestore === 'function') {
            actualizarEnFirestore(paciente).catch(error => {
                console.warn('Actualizado en localStorage, Firebase error:', error);
            });
        }

        return true;
    }
    return false;
}

// Eliminar paciente
function eliminar(id) {
    const pacientes = obtenerTodos();
    const paciente = pacientes.find(p => p.id === id);
    const filtered = pacientes.filter(p => p.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));

    // Eliminar de Firebase
    if (paciente && paciente.firebaseId && typeof eliminarDeFirestore === 'function') {
        eliminarDeFirestore(paciente.firebaseId).catch(error => {
            console.warn('Eliminado en localStorage, Firebase error:', error);
        });
    }
}

// Exportar datos (backup)
function exportarDatos() {
    const pacientes = obtenerTodos();
    const json = JSON.stringify(pacientes, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ODONPEI_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
}

// Importar datos (restore)
function importarDatos(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const pacientes = JSON.parse(e.target.result);
            if (Array.isArray(pacientes)) {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(pacientes));
                alert('✅ Datos importados correctamente');
                location.reload();
            } else {
                alert('❌ Formato de archivo inválido');
            }
        } catch (error) {
            alert('❌ Error al importar: ' + error.message);
        }
    };
    reader.readAsText(file);
}

// ========== LIMPIAR PACIENTES DUPLICADOS ==========
// Durante meses los pacientes se guardaron con addDoc, que crea un documento
// NUEVO cada vez. Cada dispositivo que subía su copia generaba otro documento
// del mismo paciente: se llegó a 303 documentos para 77 pacientes.
// Esto deja UN documento por paciente, con el id del paciente como id del
// documento (igual que los turnos), y borra las copias.

// Entre varias copias del mismo paciente, cuál tiene los datos más completos
function puntajeCopiaPaciente(p) {
    const dp = p.datosPersonales || {};
    let s = 0;
    if (String(dp.telefono || '').startsWith('+54')) s += 1000;   // teléfono ya unificado
    if (dp.telefono2) s += 100;
    s += Object.values(dp).filter(v => String(v || '').trim()).length * 10;
    if (p.odontograma) s += 50;
    s += (p.fotos?.length || 0) * 3 + (p.archivos?.length || 0) * 3;
    if (p.tratamientos?.realizados) s += 5;
    if (p.tratamientos?.propuesta) s += 5;
    return s;
}

// Corre sola al abrir la app. Sin botón y sin preguntar nada: junta las copias
// de cada paciente en un solo documento y borra las sobrantes.
// Es seguro porque antes de borrar VERIFICA que el documento bueno quedó escrito.
async function deduplicarPacientesAuto() {
    if (typeof obtenerDesdePacientesFirestore !== 'function') return;

    let todos;
    try {
        todos = await obtenerDesdePacientesFirestore();
    } catch (e) {
        console.warn('No se pudieron leer los pacientes para deduplicar:', e);
        return;
    }

    // Agrupar por el id interno del paciente
    const grupos = {};
    todos.forEach(p => { if (p.id) (grupos[p.id] = grupos[p.id] || []).push(p); });

    const ids = Object.keys(grupos);
    if (todos.length === ids.length) return;   // no hay nada repetido, seguimos de largo

    console.log(`🧹 ${todos.length} documentos para ${ids.length} pacientes. Limpiando duplicados...`);

    let borrados = 0, errores = 0;

    for (const id of ids) {
        const copias = grupos[id];
        if (copias.length === 1) continue;

        // Gana la copia con los datos más completos
        const mejor = copias.reduce((a, b) => puntajeCopiaPaciente(b) > puntajeCopiaPaciente(a) ? b : a);

        // El documento bueno lleva el id del paciente como id de documento
        if (mejor.firebaseId !== id) {
            const guardado = await guardarEnFirestore({ ...mejor, firebaseId: id });
            if (!guardado) { errores++; continue; }
        }

        // ANTES de borrar nada, confirmar que el documento bueno está en la nube
        if (typeof existePacienteEnFirestore === 'function') {
            const existe = await existePacienteEnFirestore(id);
            if (!existe) { errores++; continue; }
        }

        for (const c of copias) {
            if (c.firebaseId && c.firebaseId !== id) {
                const ok = await eliminarDeFirestore(c.firebaseId);
                if (ok) borrados++; else errores++;
            }
        }
    }

    console.log(`✅ Duplicados limpiados: ${borrados} copia(s) borrada(s)` + (errores ? `, ${errores} error(es)` : ''));
    if (typeof cargarPacientes === 'function') cargarPacientes();
}

// Sincronizar desde Firebase al iniciar (si está disponible)
async function sincronizarDesdeFirebase() {
    if (typeof obtenerDesdePacientesFirestore !== 'function') return false;
    try {
        const pacientesFirebase = await obtenerDesdePacientesFirestore();
        if (pacientesFirebase.length > 0) {
            // Firebase tiene datos → usarlos como fuente de verdad
            console.log('✅ Cargando datos desde Firebase...');
            localStorage.setItem(STORAGE_KEY, JSON.stringify(pacientesFirebase));
            if (typeof cargarPacientes === 'function') cargarPacientes();
            return true;
        } else {
            // Firebase vacío → subir datos locales si existen
            const locales = obtenerTodos();
            if (locales.length > 0) {
                console.log('⬆️ Migrando datos locales a Firebase...');
                for (const p of locales) {
                    if (!p.firebaseId) {
                        await guardarEnFirestore(p);
                    }
                }
                localStorage.setItem(STORAGE_KEY, JSON.stringify(locales));
                console.log('✅ Migración completada');
            }
        }
    } catch (error) {
        console.warn('Error sincronizando desde Firebase:', error);
    }
    return false;
}

// ========== EMPROLIJAR LOS NOMBRES VIEJOS ==========
// Desde el 6/10/2026 todo lo que se carga queda en mayúscula solo. Pero lo que
// ya estaba cargado antes se quedó como estaba: en los turnos, más de la mitad
// tenían minúsculas ("lopez noemi", "Romina sarmiento").
// Esto los empareja una sola vez. Toca SOLO los campos cortos: los textos
// clínicos largos quedan como están, porque en mayúscula no se leen.

const CAMPOS_CORTOS_PACIENTE = ['nombre', 'alias', 'domicilio', 'nombrePadre',
                                'obraSocial', 'nAfiliado', 'dni', 'telefonoRef', 'telefono2Ref'];
const FLAG_NOMBRES = 'ODONPEI_NOMBRES_NORMALIZADOS';

function necesitaMayusculas(valor) {
    return typeof valor === 'string' && valor.trim() && valor !== valor.toUpperCase();
}

async function normalizarNombresViejosAuto(pacientesYaLeidos) {
    if (localStorage.getItem(FLAG_NOMBRES) === 'si') return;   // ya se hizo en este dispositivo

    let pacientesArreglados = 0, turnosArreglados = 0, errores = 0;

    // --- Pacientes (se reusa la lista que ya se leyó, para no pedirla de nuevo) ---
    try {
        const pacientes = pacientesYaLeidos || await obtenerDesdePacientesFirestore();
        for (const p of pacientes) {
            const dp = p.datosPersonales;
            if (!dp) continue;
            let cambio = false;
            for (const campo of CAMPOS_CORTOS_PACIENTE) {
                if (necesitaMayusculas(dp[campo])) { dp[campo] = dp[campo].toUpperCase(); cambio = true; }
            }
            if (!cambio) continue;
            const docId = p.id || p.firebaseId;
            if (!docId) continue;
            // Solo datosPersonales: mandar la ficha entera con fotos puede pasarse del límite
            const ok = await actualizarCamposPacienteEnFirestore(docId, { datosPersonales: dp });
            if (ok) pacientesArreglados++; else errores++;
        }
    } catch (e) { console.warn('Normalizando nombres de pacientes:', e); errores++; }

    // --- Turnos ---
    try {
        if (typeof obtenerTurnosDesdeFirestore === 'function') {
            const turnos = await obtenerTurnosDesdeFirestore();
            for (const t of turnos) {
                if (!necesitaMayusculas(t.pacienteNombre)) continue;
                t.pacienteNombre = t.pacienteNombre.toUpperCase();
                const ok = await actualizarTurnoEnFirestore(t);
                if (ok !== false) turnosArreglados++; else errores++;
            }
        }
    } catch (e) { console.warn('Normalizando nombres de turnos:', e); errores++; }

    if (!errores) localStorage.setItem(FLAG_NOMBRES, 'si');   // si falló algo, se reintenta la próxima

    if (pacientesArreglados || turnosArreglados) {
        console.log(`✅ Nombres emparejados a mayúscula: ${pacientesArreglados} paciente(s), ${turnosArreglados} turno(s)` +
                    (errores ? ` · ${errores} error(es), se reintenta al volver a entrar` : ''));
        if (typeof cargarPacientes === 'function') cargarPacientes();
    }
}

// Todo lo que toca Firebase se hace DESPUÉS de que el login esté confirmado.
// Antes esto corría 1,5 segundos después de abrir la página, con la pantalla de
// login todavía puesta: con las reglas nuevas esas lecturas se rechazan y el
// escuchador en tiempo real muere sin volver a levantarse, así que los pacientes
// dejaban de sincronizarse entre la compu y la tablet.
async function sincronizarPacientesConLaNube() {
        // 1. Subir los pacientes que se crearon acá y NUNCA llegaron a la nube.
        //
        //    OJO con la condición: antes decía solo "si no está en la nube, subilo",
        //    y eso RESUCITABA todo lo borrado. El dispositivo no puede distinguir
        //    entre "esto nunca se subió" y "esto lo borraron a propósito", así que
        //    devolvía a la nube fichas eliminadas días o meses antes.
        //    Pasó de verdad: una limpieza de 20 fichas duplicadas se deshizo sola
        //    cuando alguien abrió la app.
        //
        //    La marca es `firebaseId`: se escribe cuando el paciente se sube bien.
        //    Si lo tiene y no está en la nube, es porque lo borraron. No se sube.
        //    Es el mismo criterio que ya usaban los turnos.
        if (typeof obtenerDesdePacientesFirestore === 'function' && typeof guardarEnFirestore === 'function') {
            try {
                const remotos = await obtenerDesdePacientesFirestore();
                const idsRemotos = new Set(remotos.map(p => p.id));
                const locales = obtenerTodos();
                const nuncaSubidos = locales.filter(p => !p.firebaseId && !idsRemotos.has(p.id));
                for (const p of nuncaSubidos) await guardarEnFirestore(p);
                if (nuncaSubidos.length) console.log(`⬆️ ${nuncaSubidos.length} paciente(s) que faltaban subir`);
            } catch (e) { console.warn('Subida inicial pacientes:', e); }
        }
        // 2. Mantenimiento automático, sin botones y sin preguntar nada:
        //    primero se juntan las copias repetidas de cada paciente y después se
        //    dejan todos los teléfonos en el mismo formato. Las dos rutinas son
        //    idempotentes: si no hay nada que hacer, no hacen nada.
        try {
            await deduplicarPacientesAuto();
        } catch (e) { console.warn('Deduplicando pacientes:', e); }

        // Emparejar a mayúscula los nombres cargados antes del 6/10/2026
        try {
            await normalizarNombresViejosAuto();
        } catch (e) { console.warn('Normalizando nombres:', e); }

        // 3. Escuchar en tiempo real — SOLO muestra, nunca sube (evita bucle/duplicados)
        if (typeof sincronizarEnTiempoReal === 'function') {
            sincronizarEnTiempoReal((pacientesRemotos) => {
                const locales = obtenerTodos();
                const idsRemotos = new Set(pacientesRemotos.map(p => p.id));
                // Lo que no está en la nube solo sobrevive acá si NUNCA se subió.
                // Si tiene firebaseId y ya no está arriba, lo borraron en otro
                // dispositivo: hay que soltarlo, no conservarlo. Si no, cada
                // máquina se queda con su propia copia de lo eliminado y lo
                // vuelve a mostrar como si existiera.
                const soloLocales = locales.filter(p => !idsRemotos.has(p.id) && !p.firebaseId);

                // Mientras queden documentos duplicados en la nube, dejar UNA sola
                // copia de cada paciente (la más completa). Si no, la lista muestra
                // el mismo paciente 3 veces y el localStorage se llena al pedo.
                const porId = new Map();
                for (const p of [...pacientesRemotos, ...soloLocales]) {
                    const previo = porId.get(p.id);
                    if (!previo || puntajeCopiaPaciente(p) > puntajeCopiaPaciente(previo)) {
                        porId.set(p.id, p);
                    }
                }

                try {
                    localStorage.setItem(STORAGE_KEY, JSON.stringify([...porId.values()]));
                } catch (e) {
                    // Se llenó el localStorage (fotos y odontogramas en base64 ocupan mucho)
                    console.warn('No se pudo guardar la copia local, se sigue con la de la nube:', e);
                }
                if (typeof cargarPacientes === 'function') cargarPacientes();

                // Los teléfonos se unifican DESPUÉS de tener los datos frescos de la
                // nube. Si se hiciera antes, se trabajaría sobre una copia local vieja
                // y quedarían números sin corregir (fue justo lo que pasó la vez pasada).
                if (!celularesYaUnificados && typeof unificarCelularesAuto === 'function') {
                    celularesYaUnificados = true;
                    unificarCelularesAuto().catch(e => console.warn('Unificando teléfonos:', e));
                }
            });
        }
}

window.addEventListener('load', () => {
    // El pequeño retraso es solo para darle tiempo a firebase-config.js (que es
    // un módulo) a publicar sus funciones en window
    setTimeout(() => {
        if (typeof cuandoHayaLogin === 'function') {
            cuandoHayaLogin(() => {
                sincronizarPacientesConLaNube().catch(e => console.warn('Sync pacientes:', e));
            });
        } else {
            // Si por lo que sea Firebase no cargó, al menos que la app no quede trabada
            sincronizarPacientesConLaNube().catch(e => console.warn('Sync pacientes:', e));
        }
    }, 1000);
});
