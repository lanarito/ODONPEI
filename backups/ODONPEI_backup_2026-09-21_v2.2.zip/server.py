#!/usr/bin/env python3
import http.server
import socketserver
import os

os.chdir('c:\\Github repos\\ODONPEI')

PORT = 8000
Handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Servidor running en http://localhost:{PORT}/")
    print("Presiona Ctrl+C para detener")
    httpd.serve_forever()
