# Simple HTTP Server para ODONPEI
$port = 8000
$path = "c:\Github repos\ODONPEI"

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Start()

Write-Host "Servidor ODONPEI corriendo en: http://localhost:$port/"
Write-Host "Presiona Ctrl+C para detener"

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $filename = $request.Url.LocalPath
        if ($filename -eq "/") {
            $filename = "/index.html"
        }

        $filepath = Join-Path $path $filename.TrimStart("/")

        if (Test-Path $filepath) {
            $file = Get-Item $filepath
            $response.StatusCode = 200

            # Determinar content type
            $contentType = "text/plain"
            if ($filepath.EndsWith(".html")) { $contentType = "text/html" }
            elseif ($filepath.EndsWith(".css")) { $contentType = "text/css" }
            elseif ($filepath.EndsWith(".js")) { $contentType = "application/javascript" }
            elseif ($filepath.EndsWith(".png")) { $contentType = "image/png" }
            elseif ($filepath.EndsWith(".jpg")) { $contentType = "image/jpeg" }
            elseif ($filepath.EndsWith(".json")) { $contentType = "application/json" }

            $response.ContentType = $contentType

            if ($filepath.EndsWith(".png") -or $filepath.EndsWith(".jpg")) {
                $buffer = [System.IO.File]::ReadAllBytes($filepath)
                $response.OutputStream.Write($buffer, 0, $buffer.Length)
            } else {
                $content = Get-Content -Path $filepath -Raw
                $buffer = [System.Text.Encoding]::UTF8.GetBytes($content)
                $response.OutputStream.Write($buffer, 0, $buffer.Length)
            }
        } else {
            $response.StatusCode = 404
            $content = "404 - Not Found"
            $buffer = [System.Text.Encoding]::UTF8.GetBytes($content)
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        }

        $response.OutputStream.Close()
    } catch {
        Write-Host "Error: $_"
    }
}

$listener.Stop()
