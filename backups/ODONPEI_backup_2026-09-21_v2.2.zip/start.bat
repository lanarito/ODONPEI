@echo off
cd /d "c:\Github repos\ODONPEI"
start index.html
